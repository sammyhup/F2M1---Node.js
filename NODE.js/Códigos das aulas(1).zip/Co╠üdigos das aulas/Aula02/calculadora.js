exports.adicao = function adicao(x, y){
    return x + y;
  }
  
  exports.subtracao = function subtracao(x, y){
    return x - y;
  }
  
  exports.mult = function mult(x, y){
    return x * y;
  }
  
  exports.div = function div(x, y){
    return x / y;
  }