const axios = require('./api.js');

async function carregarEstados(){

  try{
    var response = await axios.api.get('/estados/ES');
    console.log(response.data);
  }catch(erro){
    console.log('Ocorreu um erro ao buscar o estado');
  }
  
}

async function alterarEstado(){

  try{
    var response = await axios.api.put('/estados/ES', {
      nome: 'Espírito Santo'
    });
  }catch(erro){
    console.log('Ocorreu um erro ao alterar estado');
  }
}

async function incluirEstado(){

  try{
    var response = await axios.api.post('/estados', {
      id: 'BA',
      nome: 'Bahia'
    });

    console.log(response.data);
  }catch(erro){
    console.log('Ocorreu um erro ao incluir o novo estado');
  }
}

function deletarEstado(){

  axios.api.delete('/estados/SP')
  .then(() => {
    console.log('Estado deletado com sucesso!');
  })
  .catch((erro) => {
    console.log('Ocorreu um erro ao deletar o estado');
  });
}

//carregarEstados();
//alterarEstado();
//incluirEstado();
deletarEstado();
