const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

const alunos = [];

rl.question('Digite o nome do aluno: ', (nome) => {
  let i = 0;

  const adicionarNota = () => {
    rl.question('Digite a nota do aluno: ', (nota) => {
      alunos.push({
        nome: nome,
        nota: parseFloat(nota)
      });

      i++;

      if (i === 10) {
        // Quando todas as notas tiverem sido adicionadas
        // Realiza as operações
        let maiorNota = -Infinity;
        let menorNota = Infinity;
        let nomeMaiorNota = '';
        let nomeMenorNota = '';
        let somaNotas = 0;
        let qtdAprovados = 0;
        let qtdReprovados = 0;

        for (const aluno of alunos) {
          // Verifica a maior nota
          if (aluno.nota > maiorNota) {
            maiorNota = aluno.nota;
            nomeMaiorNota = aluno.nome;
          }

          // Verifica a menor nota
          if (aluno.nota < menorNota) {
            menorNota = aluno.nota;
            nomeMenorNota = aluno.nome;
          }

          // Soma as notas para calcular a média
          somaNotas += aluno.nota;

          // Verifica se o aluno foi aprovado ou reprovado
          if (aluno.nota >= 60) {
            qtdAprovados++;
          } else {
            qtdReprovados++;
          }
        }

        // Calcula a média das notas
        const media = somaNotas / alunos.length;

        // Exibe os resultados
        console.log(`A maior nota foi ${maiorNota}, tirada por ${nomeMaiorNota}`);
        console.log(`A menor nota foi ${menorNota}, tirada por ${nomeMenorNota}`);
        console.log(`A média das notas foi ${media}`);
        console.log(`A quantidade de alunos aprovados foi ${qtdAprovados}`);
        console.log(`A quantidade de alunos reprovados foi ${qtdReprovados}`);

        rl.close();
      } else {
        // Se ainda não tiverem sido adicionadas as 10 notas
        rl.question('Digite o nome do aluno: ', (novoNome) => {
          nome = novoNome;
          adicionarNota();
        });
      }
    });
  };

  adicionarNota();
});
